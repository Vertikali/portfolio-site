Free-Social-Icons
=================

Vector based social icons made with Sketch App for Mac by <a href="http://twitter.com/_neilorangepeel">@_neilorangepeel</a>

Rdio and Spotify Icons by @rafahari
